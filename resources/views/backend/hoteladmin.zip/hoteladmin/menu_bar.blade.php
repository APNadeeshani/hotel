<div class="page-sidebar page-sidebar-fixed scroll">
  <ul class="x-navigation nav">
    <li class="xn-logo">
    	<a>Resturant</a><a href="#" class="x-navigation-control"></a>
    </li>
    <li class="active">
    	<a href="{{url('/hotel/welcome')}}"><span class="fa fa-home">&nbsp;</span><span class="xn-text">Home</span></a>
    </li>
    <li class="active">
    	<a href="{{url('/hotel/admin/edit')}}"><span class="fa fa-cogs">&nbsp;</span><span class="xn-text">Home</span></a>
    </li>
    <li class="active">
    	<a href="{{url('/hotel/admin/available')}}"><span class="fa fa-tasks">&nbsp;</span><span class="xn-text">Home</span></a>
    </li>
	</ul>
</div>