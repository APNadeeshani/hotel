# html_form_login_registration
HTML, CSS Login and Registration Forms
Just a simple template for Login and Registratin forms
